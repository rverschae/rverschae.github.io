% Read and display Image (4 exposures)
m = imread('frame-431.jpg');
imshow(m)

% Anotate images
%[X,Y] = getpts()

% Annotated box centers of the 24 reference colors:
Xc = [488.3717 533.0812 580.8049 634.0546 689.3136 748.5914 462.7516 510.4753 559.7060 614.9651 674.7453 739.0467 431.1032 479.8316 533.0812 590.3497 655.1535 723.9761 401.9666 448.1833 500.4282 565.2319 633.5522 711.4172]
Yc = [662.5786 671.1186 680.6634 692.2175 703.7717 713.3164 696.7387 709.2976 720.3494 730.8988 745.4671 758.5284 737.4295 750.4907 766.5660 783.1437 799.2191 814.2897 780.1296 798.7167 818.3086 839.9098 856.4875 873.0652]

% Display Image (longest exposure)
imshow(m(1:end,3*1280+[1:1280],1:end)*2)
hold on; 
for i =1:24
	plot(Xc(i),Yc(i),'r.','MarkerSize',50)
end

%Colors (ground truth) 
sRGB = [115 82 68; 194 150 130; 98 122 157; 87 108 67; 133 128 177; 103 189 170; 214 126 44; 80 91 166; 193 90 99; 94 60 108; 157 188 64; 224 163 46; 56 61 150; 70 148 73; 175 54 60; 231 199 31; 187 86 149; 8 133 161; 243 243 242; 200 200 200; 160 160 160; 122 122 121; 85 85 85; 52 52 52];

r = 20; % Radio of anotation
hold off
imshow(m(1:end,3*1280+[1:1280],1:end)*2)
hold on

% Plot reference colors on top of the image
for i =1:24
%	rectangle('Position', [Xc(i)-r/2, Yc(i)-r/2, r, r], 'Curvature', [1 1], 'FaceColor', sRGB(i,:)/255);
	rectangle('Position', [Xc(i)-r/2, Yc(i)-r/2, r, r], 'Curvature', [0 0], 'FaceColor', sRGB(i,:)/255, 'EdgeColor', [1 1 1]);
end

% Crop longest exposure
m2 = m(1:end,3*1280+[1:1280],1:end)*2;

% Get un-calibrated data
for i =1:24
	data{i} = m2(round(Yc(i)-r/2:Yc(i)+r/2), round(Xc(i)-r/2:Xc(i)+r/2),:);
	data_avg{i} = mean(mean(data{i}));
	data_avg{i} = data_avg{i}(:);
	m2(round(Yc(i)-r/2:Yc(i)+r/2), round(Xc(i)-r/2:Xc(i)+r/2),1) = data_avg{i}(1);
	m2(round(Yc(i)-r/2:Yc(i)+r/2), round(Xc(i)-r/2:Xc(i)+r/2),2) = data_avg{i}(2);
	m2(round(Yc(i)-r/2:Yc(i)+r/2), round(Xc(i)-r/2:Xc(i)+r/2),3) = data_avg{i}(3);
	rectangle('Position', [Xc(i)-r/4, Yc(i)-r/4, r/2, r/2], 'Curvature', [0 0], 'FaceColor', sRGB(i,:)/255);
end

% Plot average color of each region
imshow(m2)
data_avg{i}./sRGB(i);
for i =1:24
	rectangle('Position', [Xc(i)-r/4, Yc(i)-r/4, r/2, r/2], 'Curvature', [0 0], 'FaceColor', sRGB(i,:)/255);
	data_toFit(i,:) = data_avg{i};
end

% Fit linear model for each color channel
mdlR = fitlm(data_toFit,sRGB(:,1),'linear');
mdlG = fitlm(data_toFit,sRGB(:,2),'linear');
mdlB = fitlm(data_toFit,sRGB(:,3),'linear');

% Get parameters of fitted model
b(1) = mdlR.Coefficients.Estimate(1);
b(2) = mdlG.Coefficients.Estimate(1);
b(3) = mdlB.Coefficients.Estimate(1);

M(1,:) = mdlR.Coefficients.Estimate(2:4);
M(2,:) = mdlG.Coefficients.Estimate(2:4);
M(3,:) = mdlB.Coefficients.Estimate(2:4);


% Get calibrated values
pred = data_toFit*(M');
for i =1:24
	pred(i,:) = pred(i,:)+b;
end

% Saturate values outside the range
pred(find(pred > 255)) = 255;
pred(find(pred < 0)) = 0;

% Plot calibrated results
figure(1);
for i =1:24
	rectangle('Position', [Xc(i)-r/8, Yc(i)-r/8, r/4, r/4], 'Curvature', [0 0], 'FaceColor', pred(i,:)/255);
end

m3 = m;

% Simple calibration test
for i =1:1280
	for j =1:5120
		p = m3(i,j,:);
		p = double(p(:));
		pp = M*double(p)+b';
		m3(i,j,:) = pp;
	end
end

figure(3);
imshow(m3)

